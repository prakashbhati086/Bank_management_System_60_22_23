import java.util.*;

class BankAccount {
    int balance;
    int previousTransaction;
    String customerName;
    String customerId;

    BankAccount(String cname, String cid) {
        customerName = cname;
        customerId = cid;
    }

    void deposit(int amount) {
        if (amount != 0) {
            balance += amount;
            previousTransaction = amount;
             System.out.println("Deposit successful! Your new balance is: " + balance);
        }
    }

    void withdraw(int amount) {
        if (amount > balance) {
      System.out.println("Insufficient balance!");
    }
    else{
            balance -= amount;
            previousTransaction = -amount;
             System.out.println("Withdrawal successful! Your new balance is: " + balance);
    }
    }

    void getPreviousTransaction() {
        if (previousTransaction > 0) {
            System.out.println("Deposited: " + previousTransaction);
        } else if (previousTransaction < 0) {
            System.out.println("Withdraw: " + Math.abs(previousTransaction));
        } else {
            System.out.println("No transaction occurred.");
        }
    }

    void showMenu() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Welcome " + customerName);
        System.out.println("Your ID " + customerId);
        System.out.println("\n");

        while (true) {
            System.out.println("1 : Check your Balance");
            System.out.println("2 : Deposit");
            System.out.println("3 : Withdraw");
            System.out.println("4 : Previous Transaction");
            System.out.println("5 : Exit The System");

            try {
                System.out.print("Enter your Option: ");
                int option = sc.nextInt();
                System.out.println();

                switch (option) {
                    case 1:
                        System.out.println("Balance = " + balance);
                        break;

                    case 2:
                        System.out.println("Enter an amount to deposit: ");
                        int amount = sc.nextInt();
                        deposit(amount);
                        System.out.println();
                        break;

                    case 3:
                        System.out.println("Enter an amount to withdraw: ");
                        int amount2 = sc.nextInt();
                        withdraw(amount2);
                        System.out.println();
                        break;

                    case 4:
                        getPreviousTransaction();
                        System.out.println();
                        break;

                    case 5:
                        System.out.println("Thank you for using our bank.");
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Invalid Option!! Please Enter Correct Option");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input, please try again.");
                sc.nextLine();
            } catch (Exception e) {
                System.out.println("An error occurred, please try again.");
                sc.nextLine();
            } 
        }
    }
}

public class BankingSystem {
    public static void main(String[] args) {
        BankAccount o = new BankAccount("Ashok", "12113114");
        o.showMenu();
    }
}